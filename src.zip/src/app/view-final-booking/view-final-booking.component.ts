import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-final-booking',
  templateUrl: './view-final-booking.component.html',
  styleUrls: ['./view-final-booking.component.css']
})
export class ViewFinalBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
