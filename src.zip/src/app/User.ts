export class User{
    public userType:string;
    public userId:number;
    public userName:string;
    public userPassword:string; 
    public userPhone:number;
    public userEmail:string;

    
}