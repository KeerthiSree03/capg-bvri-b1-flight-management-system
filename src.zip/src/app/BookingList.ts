import { Booking } from './Booking';

export class BookingList
{
    public bookingList : Booking[];
}