import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { CustomerComponent } from './customer/customer.component';
import { HomePageComponent } from './home-page/home-page.component';
import { AddAirportComponent } from './add-airport/add-airport.component';
import { ViewAirportlistComponent } from './view-airportlist/view-airportlist.component';
import { ViewAirportComponent } from './view-airport/view-airport.component';
import { CheckFlightWithIdComponent } from './check-flight-with-id/check-flight-with-id.component';
import { CheckBySourceAndDestinationComponent } from './check-by-source-and-destination/check-by-source-and-destination.component';
import { CheckTheSeatsComponent } from './check-the-seats/check-the-seats.component';
import { AddComponent } from './add-schedule/add.component';
import { ViewComponent } from './view-schedule/view.component';
import { ModifyComponent } from './modify-schedule/modify.component';
import { DeleteComponent } from './delete-schedule/delete.component';
import { AddflightComponent } from './add-flight/addflight.component';
import { ViewflightComponent } from './view-flight/viewflight.component';
import { SearchflightComponent } from './search-flight/searchflight.component';
import { ModifyflightComponent } from './modify-flight/modifyflight.component';
import { AddBookingComponent } from './add-booking/add-booking.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';
import { DeleteBookingComponent } from './delete-booking/delete-booking.component';
import { ModifyBookingComponent } from './modify-booking/modify-booking.component';
import { AddPassengerComponent } from './add-passenger/add-passenger.component';
import { PassengerListComponent } from './passenger-list/passenger-list.component';
import { ViewPassengerComponent } from './view-passenger/view-passenger.component';
import { UpdatePassengerComponent } from './update-passenger/update-passenger.component';

import { AddAccountComponent } from './add-account/add-account.component';
import { LoginComponent } from './login/login.component';
import { ViewAllFlightsComponent } from './view-all-flights/view-all-flights.component';
import { ViewFinalBookingComponent } from './view-final-booking/view-final-booking.component';


const routes: Routes = [

  
  {
    path:"login/admin", component:AdminComponent
  },
  {
    path:"login/customer", component:CustomerComponent
  },
  
  {
    path:"home", component:HomePageComponent
  },
  
  {
    path:"add-airport", component:AddAirportComponent
  },
  {
    path:"view-airportlist", component:ViewAirportlistComponent
  },
  {
    path:"view-airport/airportcode/:airportCode",component:ViewAirportComponent
  },

  {path:"check-flight-with-id", component:CheckFlightWithIdComponent},
  {path:"check-by-source-and-destination", component:CheckBySourceAndDestinationComponent},
  {path:"check-the-seats", component:CheckTheSeatsComponent},


  {path:'add',component:AddComponent},
  {path:'view',component:ViewComponent},
  {path:'modify/:scheduledFlightId',component:ModifyComponent},
  {path:'delete',component:DeleteComponent},

  {path: 'add-flight',component:AddflightComponent},
  {path: 'view-flight',component:ViewflightComponent},
  {path: 'search-flight',component:SearchflightComponent},
  {path: 'modify-flight/:flightNumber',component:ModifyflightComponent},
  
  {
    path:"customer/add-booking", component:AddBookingComponent
  },
  
  
  
  {
    path:"delete-booking", component:DeleteBookingComponent
  },
  {
    path:"modify", component:ModifyBookingComponent
  },
 
  {
    path:"add-passenger", component:AddPassengerComponent
  },
 {
    path:"passenger-list", component:PassengerListComponent
  },

  {
    path:"view-passenger", component:ViewPassengerComponent

  },
  
  {
    path:"update-passenger", component:UpdatePassengerComponent
  },

{
path:"", component:HomePageComponent
},

{
  path:"add-account", component:AddAccountComponent
},
{
  path:"login", component:LoginComponent 
},
{
  path:"view-all-flights", component:ViewAllFlightsComponent
},
{
  path:"customer/add-booking/view-booking/:id", component:ViewBookingComponent
},
{
  path:"view-final-booking", component:ViewFinalBookingComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
