export class Booking{
                                      
                                     
    bookingId:number;
    userId:number;
    bookingDate:Date;
    passengerList = [];    
	ticketCost:number;
    flightNumber:number;
    noOfPassengers:number;
    
} 