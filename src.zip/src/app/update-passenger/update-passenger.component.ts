import { Component, OnInit } from '@angular/core';


import { Passenger } from '../Passenger';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-update-passenger',
  templateUrl: './update-passenger.component.html',
  styleUrls: ['./update-passenger.component.css']
})
export class UpdatePassengerComponent implements OnInit {

  
passenger:Passenger=new Passenger();
  constructor(private passengerApiService: ServiceService) { }

  ngOnInit(): void {
  }
  updatePassenger()
{
  console.log(this.passenger);

  this.passengerApiService.updatePassenger(this.passenger).subscribe((success)=>{
    alert("Passenger updated");
  },
  (error)=>
  {
    alert("Failed to update Passenger");
  });
}
}
