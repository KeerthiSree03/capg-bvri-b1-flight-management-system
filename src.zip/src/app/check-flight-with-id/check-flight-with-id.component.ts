import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { ScheduledFlight } from '../ScheduledFlight'
import { HttpClient } from '@angular/common/http';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-check-flight-with-id',
  templateUrl: './check-flight-with-id.component.html',
  styleUrls: ['./check-flight-with-id.component.css']
})
export class CheckFlightWithIdComponent implements OnInit {

  constructor(private router:Router, private userDataService: ServiceService, private route: ActivatedRoute, private httpClient: HttpClient) { }
  flight: number;
  flightNumber: number;
  scheduledFlight: ScheduledFlight

  ngOnInit(): void {
  }

  search() {
    console.log(this.flightNumber);
    // this.httpClient.get(this.baseUrl+"/"+this.flightNumber);
    this.userDataService.checkFlight(this.flightNumber).subscribe(
      (success) => {
        alert("The flight is available");
        //this.router.navigate(["/check-the-seats"]);
      },

      (error) => {
        alert("The flight is not available");
      }
    );
  }
}