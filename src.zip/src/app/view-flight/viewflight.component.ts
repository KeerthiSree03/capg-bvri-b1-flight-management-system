import { Component, OnInit } from '@angular/core';
import { Flight } from '../Flight';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewflight',
  templateUrl: './viewflight.component.html',
  styleUrls: ['./viewflight.component.css']
})
export class ViewflightComponent implements OnInit {


  flights:Flight[];
  
  constructor(private flightapiservice:ServiceService, private router:Router) { }

  ngOnInit(): void {

    this.flightapiservice.viewFlight().subscribe(
      flights => this.flights = flights.flightList)
    }
    // handleSuccessfulResponse(response){
    //     this.flights=response.FlightList;
    //     console.log(this.flights);
  
        deleteFlight(flightNumber): void { if (confirm("Are you sure to delete")){
          this.flightapiservice.deleteFlight(flightNumber)
          .subscribe(data => {
            this.flights = this.flights.filter(u => u !== flightNumber);
          });
        }
      

        
      }
      modify(flightNumber) {

        this.router.navigate(['/modify-flight/'+flightNumber]);
      
      
      }
    }