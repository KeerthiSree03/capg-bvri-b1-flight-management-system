import { Component, OnInit } from '@angular/core';
import { Flight } from '../Flight';
import { ServiceService } from '../service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-searchflight',
  templateUrl: './searchflight.component.html',
  styleUrls: ['./searchflight.component.css']
})
export class SearchflightComponent implements OnInit {

  constructor(private flightapiservice:ServiceService, private route:ActivatedRoute, private router:Router) { }

  searchCode:number;
  flight:Flight;
  flights:Flight[];
  searchText:number;
  ngOnInit(): void {
  }

searchFlight(){
    this.route.params.subscribe(param => {
      //this.searchCode = param["flightNumber"];
      //this.searchCode=this.searchText;
      this.flightapiservice.getFlightById(this.searchText).subscribe(
        (response) => {
          this.flight = response;
          this.flightapiservice.flight=this.flight;
        }
        ,
        (error) => {
          alert("No Flight Found with Number=" + this.searchText);
        }
      );
    })

  }
  delete(flightNumber): void { if (confirm("Are you sure to delete")){
    this.flightapiservice.deleteFlight(flightNumber)
    .subscribe(data => {
      alert("deleted successfully");
      this.router.navigate(['/view-flight']);
    });

  }
}

  modify(flightNumber) {

    this.router.navigate(['/modify-flight/'+flightNumber]);


  }

}
