export class Passenger{
   
    passengerNum:number;
    passengerName:string;
  passengerAge:number;
  passengerUIN:number;
  luggage:any;

} 
