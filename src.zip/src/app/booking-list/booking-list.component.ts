import { Component, OnInit } from '@angular/core';
import { Booking } from 'src/app/Booking';

import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-booking-list',
  templateUrl: './booking-list.component.html',
  styleUrls: ['./booking-list.component.css']
})
export class BookingListComponent implements OnInit {


bookings:Array<Booking> ;
  // bookings: Booking[] ;
  constructor(private router:Router,private bookingApiService:ServiceService) { }

ngOnInit(): void {
  // this.bookingApiService.getAllBookings().subscribe(
  //   (bookings)=>{
  //       this.bookings=bookings;
  //       console.log(this.bookings);         
  //   }
  // );
   
}
}