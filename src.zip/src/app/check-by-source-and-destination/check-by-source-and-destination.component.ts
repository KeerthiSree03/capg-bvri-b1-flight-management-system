import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { ScheduledFlight } from '../ScheduledFlight';
import { Schedule } from '../Schedule';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-check-by-source-and-destination',
  templateUrl: './check-by-source-and-destination.component.html',
  styleUrls: ['./check-by-source-and-destination.component.css']
})

export class CheckBySourceAndDestinationComponent implements OnInit {

  constructor(private router:Router, private userDataService: ServiceService, private route: ActivatedRoute, private httpClient: HttpClient) { }
  sourceAirport: string;
  destinationAirport: string;
  scheduledFlight: ScheduledFlight;
  schedule: Schedule;
  ngOnInit(): void {
  }

  search() {
    // this.httpClient.get(this.baseUrl + "/source/" + this.sourceAirport + "/destination/" + this.destinationAirport)
    this.userDataService.checkSourceAndDestination(this.sourceAirport, this.destinationAirport).subscribe(  
           
      (success: any) => {
        data=>console.log(data);
        console.log("Flight available");
        alert("Flight is available");
        console.log(success);
        this.router.navigate(["/check-the-seats"]);
      },

      (error: any) => {
        console.log("Flight not available");
        alert("Flight is not available");
        console.log(error);
        this.router.navigate(["/check-by-source-and-destination"]);
      }
    );
  }
}