import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDataService } from '../user-data.service';
import { user } from '../user';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {

  constructor(private router:Router, public service: UserDataService ) { }
  public userType:string;
  public userId:number;
  public userName:string;
  public userPassword:string; 
  public userPhone:number;
  public userEmail:string;
  public newUser:user;
  ngOnInit(): void {
  }

  addAccount(){
   
    console.log(this.service.userData)
    this.service.userData.push(new user(this.userType,this.userId,this.userName,this.userPassword,this.userPhone,this.userEmail))
    console.log(this.service.userData)
    alert("Account created Successfully...!!! Please login")
    this.router.navigate(["/login"]);
  }

}
