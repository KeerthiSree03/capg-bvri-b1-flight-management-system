import { Injectable } from '@angular/core';
import { user } from './user';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserDataService {

  public userData:Array<user>;
  
  constructor(private httpClient:HttpClient) {
    httpClient.get("/assets/user-data.json").subscribe(
        (users:user[])=>{
            this.userData=users;
        }
        
    );
}}
