import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDataService } from '../user-data.service';
import { user } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router, public service: UserDataService ) { }
  public userType:string;
  public userId:number;
  public userName:string;
  public userPassword:string; 
  public userPhone:number;
  public userEmail:string;
  public loginUser:user;
  public isLoggedin:boolean;
  ngOnInit(): void {
  
  }

  login(){
  
      this.service.userData.forEach((b)=>{
        if((b.userName.toLowerCase().match(this.userName.toLowerCase()))){
          console.log(b.userName.toLowerCase().match(this.userName.toLowerCase()));
          (this.loginUser=b)}})
          console.log(this.service.userData)
          console.log(this.loginUser)
   
        if(this.loginUser.userName.toLowerCase().match(this.userName.toLowerCase())){
          if(this.loginUser.userPassword.match(this.userPassword)){
            if(this.loginUser.userType.toUpperCase().match("ADMIN")){
              
              this.router.navigate(["/login/admin"]);
              
            }
            else if(this.loginUser.userType.toUpperCase().match("USER")){
              this.router.navigate(["/login/customer"]);
            }
          }
          else
            alert("Please enter Correct Password")
        }
        else
        alert("User with "+this.userName+" does not exists");  
      }
}
      
  


