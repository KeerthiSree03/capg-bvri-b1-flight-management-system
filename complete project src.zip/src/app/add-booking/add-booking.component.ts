import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Booking } from '../Booking';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-add-booking',
  templateUrl: './add-booking.component.html',
  styleUrls: ['./add-booking.component.css']
})
export class AddBookingComponent implements OnInit {
  constructor(private router:Router,private bookingApiService:ServiceService) { }
  booking:Booking;
    ngOnInit(): void { 
      this.booking=new Booking();
    }  
  addBooking(){
    this.bookingApiService.addBooking(this.booking).subscribe(
      (success)=>{
        alert("Booking Added");
        console.log(this.booking);
      },
      (error)=>{
        alert("Error:Booking Not Added");
      }
    )
    this.router.navigate(["customer/add-booking/view-booking"]);
  }
}
