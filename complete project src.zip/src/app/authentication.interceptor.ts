import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { sequenceEqual } from 'rxjs/operators';

@Injectable()
export class AuthenticationInterceptor implements HttpInterceptor {

  constructor() {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    console.log("Request Intercepted");
   if(sessionStorage.getItem('username') && sessionStorage.getItem('token')){
     request=request.clone({
       setHeaders:{
         Authorization:sessionStorage.getItem('token')
       },
       withCredentials:true
     });
   }
    return next.handle(request);
  }
}
