import { Component, OnInit } from '@angular/core';

import { Booking } from '../Booking';
import { Router } from '@angular/router';
import { BookingList } from '../BookingList';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-delete-booking',
  templateUrl: './delete-booking.component.html',
  styleUrls: ['./delete-booking.component.css']
})
export class DeleteBookingComponent implements OnInit {

  
  booking:Booking;
  bookingId:number;
  //bookingList:Booking[];
  bookingList:Booking[];
  constructor(private router:Router,private bookingApiService:ServiceService) { }
  searchTxt=0;
  ngOnInit(): void {
    this.bookingApiService.getBookingInfo(this.bookingId).subscribe(
      (data)=> {          
              this.bookingList=data.bookingList;
      console.log(this.bookingList);         
  });
 }
deleteBooking(bookingId){
if(confirm("Sure to Delete?")){
  this.bookingApiService.deleteBooking(bookingId).subscribe(
    (success)=>{
         alert("Booking with id ["+bookingId+"] is Cancelled(Deleted)");
        this.ngOnInit(); 
        },
    (error)=>{
      alert("Cancellation Failed");
    }
  );
}
}
searchBooking(bookingId:number){
  this.bookingApiService.getBookingInfo(bookingId).subscribe(
    (booking)=>{
      this.booking=this.booking;
      console.log(booking);
    },
    (error)=>{
      this.booking=null;
      alert("Booking Not Found");
    }
  );
}

}


