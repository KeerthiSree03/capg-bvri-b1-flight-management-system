import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../User';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {

  constructor(private router:Router, public service: ServiceService ) { }
  public user:User=new User(); 
  
  ngOnInit(): void {
  }

  selectUserType:string='';

  selectChangeHandler (event: any) {
    this.selectUserType = event.target.value;
  }
   

  addAccount(){
    this.user.userType=this.selectUserType;
    console.log(this.user.userType)
      this.service.createAccount(this.user).subscribe(
          (success)=>{
            alert("Account Created Successfully...!!! Please login");
            this.router.navigate(["/login"]);
          },
          (error)=>{
            alert("Please check the entered details and try again!!!")
          })
      }
  

}
