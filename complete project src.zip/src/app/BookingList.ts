import { Booking } from './Booking';

export class BookingList
{
    public bookings:Array<Booking>;
}