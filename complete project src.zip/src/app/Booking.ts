export class Booking{
                                      
                                     
    bookingId:number;
    userId:number;
    bookingDate:Date;
    passengerList:Array<number>;    
	ticketCost:number;
    flightNumber:number;
    noOfPassengers:number;
    
} 