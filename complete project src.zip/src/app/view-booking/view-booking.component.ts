import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Booking } from 'src/app/Booking';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.css']
})
export class ViewBookingComponent implements OnInit {

  constructor(private bookingApiService:ServiceService,private route:ActivatedRoute) { }
  booking: Booking;
  bookingId:number;

  ngOnInit(): void {
    this.viewallBooking();
  }
  viewallBooking(){
    this.bookingApiService.getAllBookings().subscribe(
      (booking)=>{
        this.booking=this.booking;
        console.log(booking);
      },
      (error)=>{
        this.booking=null;
        alert("Booking Not Found");
      }
    );
}
  

searchBooking(bookingId:number){
      this.bookingApiService.getBookingInfo(bookingId).subscribe(
        (booking)=>{
          this.booking=this.booking;
          console.log(booking);
        },
        (error)=>{
          this.booking=null;
          alert("Booking Not Found");
        }
      );
  }

}




// searchId:number;
//   booking: Booking;
//   ngOnInit(): void {

//     this.route.params.subscribe(param => {
//       this.searchId = param["bookingId"];

//       this.bookingApiService.getBookingInfo(this.searchId).subscribe(
//         (response) => {
//           this.booking = response;
//           this.bookingApiService.booking=this.booking;
//         }
//         ,
//         (error) => {
//           alert("No Airport found with id = " + this.searchId);
//         }

//       );
//     })
//   }

// }
 