import { Component, OnInit } from '@angular/core';
import { Time } from '@angular/common';

import { error } from '@angular/compiler/src/util';
import { ServiceService } from '../service.service';
import { ScheduleFlightList, Schedule } from '../Schedule';
import { ScheduledFlight } from '../ScheduledFlight';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html', 
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  
  constructor(private scheduleapiservice:ServiceService) { }

  sche:ScheduledFlight;
  ngOnInit(): void {
    this.sche=new ScheduledFlight();
    this.sche.schedule = new Schedule(); 
  }

  add() 
  {
    this.scheduleapiservice.add(this.sche).subscribe(
      //data => console.log(data),
      (data) => { console.log(data); alert("Schedule Added")},
      (error) => {alert("Not Scheduled ! ")}
      //(success)=>
      //{
        //alert("Scheduled");
     // },
      //(error)=>
      //{
        //alert("Failed");
     // }
    )
  }
}
