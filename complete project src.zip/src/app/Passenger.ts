export class Passenger{
   
    passengerNumber:number;
    passengerName:string;
  passengerAge:number;
  passengerUIN:number;
  luggage:any;

} 
