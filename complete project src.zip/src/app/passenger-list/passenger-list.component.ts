import { Component, OnInit } from '@angular/core';

import { Passenger } from '../Passenger';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';


@Component({
  selector: 'app-passenger-list',
  templateUrl: './passenger-list.component.html',
  styleUrls: ['./passenger-list.component.css']
})
export class PassengerListComponent implements OnInit {
passengers:Array<Passenger> ;
passenger :Passenger= new Passenger();
  constructor(private passengerApiService:ServiceService) { }

ngOnInit(): void {

  this.passengerApiService.getAllPassengers().subscribe(
    response => this.handleSuccessfulResponse(response),);
  }
  handleSuccessfulResponse(response){
      this.passengers=response.passengerList;
      console.log(this.passengers);
}
      delete(passengerNumber): void { if (confirm("Are you sure to delete"))
      console.log(passengerNumber);
      this.passengerApiService.deletePassenger(passengerNumber)
      .subscribe(data => {
        this.passengers= this.passengers.filter(u => u !== passengerNumber);
        alert("Passenger with number ["+this.passenger.passengerNumber+"] Deleted");

      });


    }}
    
      
      
    


 




