import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Airport, AirportList } from './Airport';
import { Observable } from 'rxjs';
import { ScheduledFlight } from './ScheduledFlight';
import { Schedule, ScheduleFlightList } from './Schedule';
import { Flight, FlightList } from './Flight';
import { Booking } from './Booking';
import { Passenger } from './Passenger';
import { AuthenticationServiceService } from './authentication-service.service';
import { AuthenticationResponse } from './AuthenticationResponse';
import { UserCredentials } from './UserCredentials';
import { User } from './User';
import {map} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  airport:Airport;
  scheduledFlight: ScheduledFlight;
  schedule: Schedule;
  flight:Flight;
  booking:Booking;
  passenger:Passenger;
  auth:AuthenticationResponse;
  user:User;

  constructor(private _http:HttpClient , private authService:AuthenticationServiceService) { }

  
  private baseUrl="http://localhost:8321/users/admin";
  private baseUrl1="http://localhost:8321/users/customer";


  addAirport(airport:Airport):Observable<Airport>{
    return this._http.post<Airport>(this.baseUrl+"/airport/add",airport)
  }

  getAllAirports():Observable<AirportList>{
    return this._http.get<AirportList>(this.baseUrl+"/airport/all");
  }
  
  getAirportByCode(airportCode:string):Observable<Airport>{
    return this._http.get<Airport>(this.baseUrl+"/airport/airportcode/"+airportCode);
  }
  deleteAirport(airports){
    return this._http.delete<Airport>(this.baseUrl+"/airport/delete/"+airports.airportCode);
  }

  checkFlight(flightNumber: number) {
    console.log(flightNumber);
    
    return this._http.get(this.baseUrl1 + "/availability/" + flightNumber, { responseType: 'text' });
  }

  checkSourceAndDestination(sourceAirport: string, destinationAirport: string) {
    console.log(sourceAirport);
    console.log(destinationAirport);
  
    return this._http.get(this.baseUrl1 + "/source/" + sourceAirport + "/destination/" + destinationAirport, { responseType: 'text' })
  }

  checkAvailableSeatsAndFlightNumber(flightNumber: number, availableSeats: number) {
    console.log(availableSeats);
    console.log(flightNumber);
      
    return this._http.get(this.baseUrl1 + "/availability/" + flightNumber + "/" + availableSeats, { responseType: 'text' });
  }

  add(scheduleFlight:ScheduledFlight):Observable<ScheduledFlight>
  {
    console.log(scheduleFlight);
    return this._http.post<ScheduledFlight>(this.baseUrl+"/scheduleflight/add",scheduleFlight);

  }
  view():Observable<ScheduleFlightList>
  {
    return this._http.get<ScheduleFlightList>(this.baseUrl+"/scheduleflight/viewall");
  }
  getScheduledFlight(scheduledFlightId:number):Observable<ScheduledFlight>{

    return this._http.get<ScheduledFlight>(this.baseUrl+"/scheduleflight/id/"+scheduledFlightId);
  }
  modify(value : any):Observable<ScheduledFlight>
  {
    
    return this._http.post<ScheduledFlight>(this.baseUrl+"/scheduleflight/modify",value);
  }
  delete(scheduledFlightId:ScheduledFlight):Observable<ScheduledFlight>{

    return this._http.delete<ScheduledFlight>(this.baseUrl+"/scheduleflight/delete/"+scheduledFlightId)

  }


  getFlightById(flightNumber:number):Observable<Flight>{
    return this._http.get<Flight>(this.baseUrl+"/flights/id/"+flightNumber);
  }

  addFlight(flight:Flight):Observable<Flight>
  {
    return this._http.post<Flight>(this.baseUrl+"/flights/add",flight);
  }
  viewFlight():Observable<FlightList>
  {
    return this._http.get<FlightList>(this.baseUrl+"/flights/all");
  }
  deleteFlight(flightNumber:number):Observable<Flight>
  {
    return this._http.delete<Flight>(this.baseUrl+"/flights/deleteById/"+flightNumber);
  }
  modifyFlight( value:any):Observable<Flight>
  {
    return this._http.post<Flight>(this.baseUrl+"/flights/modify",value);
  }
  search(flightNumber:number)
  {
    return this._http.get<Flight>(this.baseUrl+"/flights/id/"+flightNumber);
  }

  addBooking(booking:Booking):Observable<Booking>{
    return this._http.post<Booking>(this.baseUrl1+"/booking/add",booking);
  }

  getBookingInfo(bookingId:number):Observable<any>{
    return this._http.get(this.baseUrl1+"/booking/id"+bookingId);
  }

  deleteBooking(bookingId:number):Observable<Booking>{
    console.log("Delete Booking Called for ubooking id : "+bookingId);
    //console.log(this.baseUrl1+"delete/id/"+bookingId);
    return this._http.delete<Booking>(this.baseUrl1+"delete/id/"+bookingId);
    
  }
  updateBooking(booking:Booking):Observable<Booking>{
    return this._http.put<Booking>(this.baseUrl1+"/booking/modify",booking);
  }

  getAllBookings():Observable<Array<Booking>>{
    return this._http.get<Array<Booking>>(this.baseUrl1+"/booking/all");
  }

  public addPassenger(passenger):Observable<Passenger>{
    console.log(passenger);
    return this._http.post<Passenger>(this.baseUrl1+"/passenger/add",passenger);
  }

  public getPassengerInfo(passengerNumber):Observable<Passenger>{
    return this._http.get<Passenger>(this.baseUrl+"/passenger/num/"+passengerNumber);
  }

  public deletePassenger(passengerNumber):Observable<Passenger>{
    return this._http.delete<Passenger>(this.baseUrl+"/passenger/delete/num/"+passengerNumber);
    
  }
  public updatePassenger(passenger):Observable<Passenger>{
    return this._http.put<Passenger>(this.baseUrl+"/passeger/update",passenger);
  }
  public getAllPassengers():Observable<Array<Passenger> >{
    return this._http.get<Array<Passenger> >(this.baseUrl+"/passenger/all");
  }
   public getCountOfPassengers():Observable<Passenger>{
     return this._http.get<Passenger>(this.baseUrl+"/passenger/getcount");
   }



    loginUser(userCredentials:UserCredentials):Observable<AuthenticationResponse>{
     return this._http.post<AuthenticationResponse>("http://localhost:8321/public/authenticate",userCredentials).pipe(
       map((token)=>{
         sessionStorage.setItem("username",userCredentials.username);
         sessionStorage.setItem("token",token.token);
         this.authService.addToken(token.token);
         return token;
       }

       )
     )
   }

   getUserByUsername(username:string):Observable<User>{
     return this._http.get<User>("http://localhost:8321/users/public/"+username,) 
  }

   createAccount(user:User):Observable<User>{
       return this._http.post<User>("http://localhost:8321/users/public/add",user)
   }



}
