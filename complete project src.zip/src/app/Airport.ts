export class Airport{
    airportName:string;
    airportCode:string;
    airportLocation:string
}
export class AirportList{

    airportList : Airport[];

}